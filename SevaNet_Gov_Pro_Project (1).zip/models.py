import sqlite3
from config import DATABASE
from datetime import datetime

def get_conn():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT UNIQUE,
        created_at TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS issues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        description TEXT,
        image TEXT,
        lat REAL,
        lng REAL,
        category TEXT,
        status TEXT DEFAULT 'Pending',
        upvotes INTEGER DEFAULT 0,
        created_at TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        issue_id INTEGER,
        user_id INTEGER,
        comment TEXT,
        created_at TEXT,
        FOREIGN KEY(issue_id) REFERENCES issues(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    )""")
    conn.commit()
    conn.close()

def create_user(phone):
    conn = get_conn()
    c = conn.cursor()
    now = datetime.utcnow().isoformat()
    c.execute("INSERT OR IGNORE INTO users (phone, created_at) VALUES (?,?)",(phone,now))
    conn.commit()
    c.execute("SELECT * FROM users WHERE phone=?",(phone,))
    user = c.fetchone()
    conn.close()
    return user

def add_issue(user_id, title, description, image, lat, lng, category):
    conn = get_conn()
    c = conn.cursor()
    now = datetime.utcnow().isoformat()
    c.execute("INSERT INTO issues (user_id,title,description,image,lat,lng,category,created_at) VALUES (?,?,?,?,?,?,?,?)",
              (user_id,title,description,image,lat,lng,category,now))
    conn.commit()
    issue_id = c.lastrowid
    conn.close()
    return issue_id

def get_issues(limit=100):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM issues ORDER BY id DESC LIMIT ?",(limit,))
    rows = c.fetchall()
    conn.close()
    return rows

def get_issue(issue_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM issues WHERE id=?",(issue_id,))
    r = c.fetchone()
    conn.close()
    return r

def update_issue_status(issue_id, status):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE issues SET status=? WHERE id=?",(status,issue_id))
    conn.commit()
    conn.close()

def add_comment(issue_id,user_id,comment):
    conn = get_conn()
    c = conn.cursor()
    now = datetime.utcnow().isoformat()
    c.execute("INSERT INTO comments (issue_id,user_id,comment,created_at) VALUES (?,?,?,?)",(issue_id,user_id,comment,now))
    conn.commit()
    conn.close()

def get_comments(issue_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM comments WHERE issue_id=? ORDER BY id ASC",(issue_id,))
    rows = c.fetchall()
    conn.close()
    return rows
