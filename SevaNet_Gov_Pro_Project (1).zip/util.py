import os
from config import ALLOWED_EXTENSIONS, UPLOAD_FOLDER
from werkzeug.utils import secure_filename
from PIL import Image

def allowed_file(filename):
    return "." in filename and filename.rsplit(".",1)[1].lower() in ALLOWED_EXTENSIONS

def save_image(file_storage, prefix=""):
    if not file_storage:
        return None
    filename = secure_filename(file_storage.filename)
    if not allowed_file(filename):
        return None
    filename = f"{prefix}_{filename}"
    path = os.path.join(UPLOAD_FOLDER, filename)
    file_storage.save(path)
    try:
        img = Image.open(path)
        img.thumbnail((1200,1200))
        img.save(path, optimize=True, quality=85)
    except Exception:
        pass
    return filename
