import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "sevanet.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"png","jpg","jpeg","gif"}
SECRET_KEY = os.environ.get("SEVANET_SECRET","change-me-in-prod")
ADMIN_PASSWORD = os.environ.get("SEVANET_ADMIN_PWD","admin123")
