// capture location
function captureLocation(){ 
  if(navigator.geolocation){ 
    navigator.geolocation.getCurrentPosition(function(p){ 
      if(document.getElementById('lat')) document.getElementById('lat').value=p.coords.latitude; 
      if(document.getElementById('lng')) document.getElementById('lng').value=p.coords.longitude;
    }); 
  } 
}
window.onload=captureLocation;
